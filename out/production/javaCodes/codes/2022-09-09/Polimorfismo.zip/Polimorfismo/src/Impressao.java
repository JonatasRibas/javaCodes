public interface Impressao {
    void imprimir(String msg);
}
