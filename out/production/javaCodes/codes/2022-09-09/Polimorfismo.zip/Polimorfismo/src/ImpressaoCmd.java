public class ImpressaoCmd implements Impressao {
    @Override
    public void imprimir(String msg){
        System.out.println(msg);
    }
}
