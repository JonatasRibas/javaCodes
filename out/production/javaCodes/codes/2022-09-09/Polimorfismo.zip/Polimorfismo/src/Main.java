public class Main {
    public static void main(String [] args){
        Impressao i1;

        i1 = new ImpressaoCmd();
        i1.imprimir("Olá");

        i1 = new ImpressaoTela();
        i1.imprimir("Olá!");




    }
}
