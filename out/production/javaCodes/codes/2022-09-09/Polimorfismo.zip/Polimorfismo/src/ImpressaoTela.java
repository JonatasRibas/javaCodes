import javax.swing.*;

public class ImpressaoTela implements Impressao {
    @Override
    public void imprimir(String msg){
        JOptionPane.showMessageDialog(null, msg);
    }
}
